# environments/qa/office_hours_scheduler.tf

module "office_hours_scheduler" {
  source = "../../modules/office_hours_scheduler"

  lambda_role_name   = "office-hours-lambda-role"
  cron_expression    = "cron(0 7,21 ? * MON-FRI *)"  # 9 AM and 9 PM CET (07:00 & 19:00 UTC)
  target_tag_key     = "Environment"
  target_tag_value   = "QA"
}
