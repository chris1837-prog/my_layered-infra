


module "office_hours_stop" {
  source = "../../modules/office_hours_scheduler"

  name            = "stop-qa-ec2"
  schedule        = "cron(0 19 ? * MON-FRI *)" # 21:00 CET = 19:00 UTC
  action          = "stop"
  ec2_tag_key     = "Environment"
  ec2_tag_value   = "QA"
}

module "office_hours_start" {
  source = "../../modules/office_hours_scheduler"

  name            = "start-qa-ec2"
  schedule        = "cron(0 7 ? * MON-FRI *)" # 09:00 CET = 07:00 UTC
  action          = "start"
  ec2_tag_key     = "Environment"
  ec2_tag_value   = "QA"
}