output "scheduler_rule_name" {
  description = "Name of the EventBridge rule for Office Hours"
  value       = aws_cloudwatch_event_rule.office_hours.name
}