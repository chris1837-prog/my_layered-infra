# modules/office_hours_scheduler/README.md

# Office Hours Scheduler (Terraform Module)

This module sets up a scheduled Lambda function to **stop** and **start** EC2 instances during off-hours in non-production environments such as QA.

## 🧠 Motivation
FinOps initiative to reduce cloud costs by stopping resources automatically during off-hours.

## ⚙️ What It Deploys
- IAM role for Lambda with EC2 + CloudWatch permissions
- Lambda function (Python) zipped and deployed
- EventBridge rule with configurable cron
- Target: EC2 instances with tag `Environment = QA`

## 📥 Inputs
| Name                | Type   | Description                            |
|---------------------|--------|----------------------------------------|
| `lambda_role_name`  | string | IAM role name for the Lambda           |
| `cron_expression`   | string | Schedule expression (e.g. stop/start)  |
| `action`            | string | Either `stop` or `start`               |
| `target_tag_key`    | string | EC2 tag key to filter (e.g. `Environment`) |
| `target_tag_value`  | string | EC2 tag value (e.g. `QA`)              |

## 📤 Outputs
- Lambda function name
- EventBridge rule name
- IAM role ARN

## 🔍 Example
See [`examples/basic_usage`](./examples/basic_usage) for a usage demo.
