import boto3
import os


ec2 = boto3.client('ec2')
action = os.environ.get('ACTION')  # either 'start' or 'stop'
tag_key = os.environ.get('TAG_KEY', 'Environment')
tag_value = os.environ.get('TAG_VALUE', 'QA')


def lambda_handler(_event, _context):
    print(f"Triggered with action={action}, tag_key={tag_key}, tag_value={tag_value}")
    filters = [{'Name': f'tag:{tag_key}', 'Values': [tag_value]}]
    instances = ec2.describe_instances(Filters=filters)
    instance_ids = [i['InstanceId']
                    for r in instances['Reservations']
                    for i in r['Instances']
                    if i['State']['Name'] in ['running', 'stopped']]
    print(f"Found instances: {instance_ids}")
    if not instance_ids:
        return f"No instances to {action}"

    if action == 'stop':
        ec2.stop_instances(InstanceIds=instance_ids)
        print(f"{action.capitalize()} request sent for: {instance_ids}")
    elif action == 'start':
        ec2.start_instances(InstanceIds=instance_ids)
        print(f"{action.capitalize()} request sent for: {instance_ids}")
    return f"{action.capitalize()}ed: {instance_ids}"
